import {defineConfig} from 'vite';
export default defineConfig({base:'./',build:{outDir:'modules/book-49',emptyOutDir:true,lib:{entry:'src/story/interactive/index.ts',name:'GailBook49',formats:['iife'],fileName:()=> 'reader.js',cssFileName:'reader'},rollupOptions:{output:{inlineDynamicImports:true}}}});
