import previous from './later-books-data';
import three from './three-books-data';
import journeyFestival from './journey-festival-data';
import weekend from './princess-weekend-data';
const raw={...previous,...three,...journeyFestival,...weekend};
import type {ObjectSpec,SceneSpec,StoryPage} from './book';
import type {ReadingLevel} from './dragon-text';
import type {StoryQuestion} from './dragon-quiz';
import type {StoryMotion} from './choreography';

export const laterKeys=['lost-lighthouse','mixed-up-museum','bridge-construction','little-robot','magic-potion','palace-friend','animal-sports-week','magic-tree-seasons','picnic-counting','journey-chances','dragon-boat-festival','princess-weekend'] as const;
export type LaterKey=typeof laterKeys[number];
type Layer=ObjectSpec&{image:string;flip?:boolean};
type Scene={mission?:StoryPage['mission'];number:number;title:string;scene:string;background:string;objects:Layer[];text:Record<ReadingLevel,string[]>;chinese:Record<ReadingLevel,string[]>};
type Vocabulary={word:string;chinese:string;image:string;cue:string};
type Manifest={title:string;chineseTitle:string;coreWords:string[];scenes:Scene[];vocabulary:Vocabulary[];quiz:{number:number;kind:string;scene:number;image?:string;question:string;options:string[];answerIndex:number;answer:string}[]};
export const laterData=raw as Record<LaterKey,Manifest>;
export function laterBookFromPath(path:string,hint?:string):LaterKey|undefined{return laterKeys.find(key=>path.endsWith(`/${key}-storybook.html`)||hint===key);}
const relative=(key:LaterKey,path:string)=>path.startsWith(`images/story/${key}-v1/`)?path.slice(`images/story/${key}-v1/`.length):'../'+path.replace('images/story/','');
const labels:Record<string,string>={gail:'Gail',mira:'Mira',ella:'Ella',alice:'Alice',guide:'guide',boat:'ship','wrong-beam':'beam','correct-beam':'beam','angle-arrow':'angle','test-card':'test',curator:'curator','wood-frame':'frame','metal-tool':'metal',record:'record','label-spiral':'label','label-statue':'label','label-footprint':'label','question-card':'question','wrong-label-':'label','short-plank':'plank','long-plank':'plank','finished-bridge':'bridge','model-bent':'model','model-supported':'support','model-arch':'arch','safety-line':'safety','greeting-card':'greeting','cloudy-vial':'mixture',moonmint:'herb',mist:'mist','magic-ball':'ball','broom-charm':'broom charm','toy-house':'house','stop-flag':'stop','card-start':'start','card-stop':'stop'};
function label(o:Layer){const id=o.id.replace(/\d+$/,'');return labels[id]||id.replaceAll('-',' ');}
export function laterLayers(key:LaterKey,s:Scene):ObjectSpec[]{return s.objects.map(o=>({...o,word:key in three||key in journeyFestival||key in weekend?o.word:label(o),image:relative(key,o.image),flipX:key==='little-robot'&&o.id==='robot'?(s.objects.find(peer=>peer.id==='gail')?.x??50)<o.x:key==='magic-potion'&&o.id==='teacher'?true:key==='palace-friend'&&o.id==='alice'? !s.objects.some(peer=>peer.id==='guest') :o.flip??false}));}
function bilingual(s:Scene,level:ReadingLevel){
 const en=s.text[level].join(' ').match(/[^.!?]+[.!?]+(?:[”"'](?=\s|$))?|[^.!?]+$/g)?.map(x=>x.trim()).filter(Boolean)||s.text[level];
 const zh=s.chinese[level].join('').match(/[^。！？]+[。！？]+|[^。！？]+$/g)?.map(x=>x.trim()).filter(Boolean)||s.chinese[level];
 return en.length===zh.length?{en,zh}:{en:s.text[level],zh:s.chinese[level]};
}
/** Stable per book and level, so returning to an unfinished quiz keeps the same choices. */
function answerPositions(key:LaterKey,level:ReadingLevel,count:number){
 const positions=Array.from({length:count},(_,i)=>i%4);
 let seed=2166136261;
 for(const char of `${key}:${level}`)seed=Math.imul(seed^char.charCodeAt(0),16777619)>>>0;
 for(let i=positions.length-1;i>0;i--){
  seed=(Math.imul(seed,1664525)+1013904223)>>>0;
  const j=seed%(i+1);
  [positions[i],positions[j]]=[positions[j],positions[i]];
 }
 return positions;
}
const specials:Partial<Record<LaterKey,Record<number,[string,string,string?]>>>={
 'mixed-up-museum':{7:['sequence','fossil','statue'],8:['sequence','wood-frame','metal-tool'],9:['drag','label-spiral','fossil'],11:['sequence','label-footprint','label-spiral'],12:['drag','label-statue','statue'],16:['drag','label-statue','statue']},
 'bridge-construction':{7:['drag','tape','short-plank'],8:['drag','tape','short-plank']},
 'little-robot':{9:['sequence','card-start,card-red,card-blue,card-yellow,card-stop'],10:['tap','card-start'],11:['sequence','card-red,card-blue,card-yellow'],12:['sequence','card-start,card-red,card-blue,card-yellow,card-stop'],13:['sequence','card-start,card-red,card-blue,card-yellow,card-stop,button'],16:['tap','card-blue'],17:['tap','button']},
 'magic-potion':{6:['sequence','recipe1','moonmint0'],8:['sequence','recipe1','moonmint0'],9:['drag','moonmint0','vial1'],13:['drag','crystal1','vial2'],14:['sequence','recipe0','cauldron1'],15:['sequence','mortar0','vial1'],17:['sequence','recipe0','cloudy-vial1'],18:['sequence','recipe0','vial1']},
 'palace-friend':{5:['sequence','alice','ella'],8:['drag','napkin1','tray0'],9:['tap','napkin0'],10:['tap','napkin0'],11:['sequence','gail,ella,alice'],14:['sequence','alice','guest'],16:['drag','napkin2','tray0'],18:['tap','pinwheel0'],19:['tap','pinwheel0']}
};
function mission(key:LaterKey,s:Scene,items:ObjectSpec[]):StoryPage['mission']{
 if(s.mission)return s.mission;
 const prop=items.find(o=>!['gail','mira','teacher','ella','alice','guest','keeper','curator','builder','robot','portal','broom-charm','magic-ball'].includes(o.id));
 const fallback=prop||items.find(o=>o.id!=='gail')||items[0];
 const special=specials[key]?.[s.number];
 if(special){
  const [type,first,second]=special;const ids=first.split(',').concat(second?[second]:[]);
  if(!ids.every(id=>items.some(o=>o.id===id)))throw Error(`Missing mission target ${key} ${s.number}`);
  const word=(id:string)=>items.find(o=>o.id===id)!.word;
  if(type==='drag')return {type,answer:first,target:second,prompt:`Move the ${word(first)} to the ${word(second!)}.`,hint:'拖到對應的位置；也可以先點物件，再點目的地。'};
  if(type==='sequence')return {type,answer:ids.at(-1)!,steps:ids,prompt:`Tap in order: ${ids.map(word).join(' → ')}.`,hint:'依圖示順序點選，一步一步完成。'};
  return {type:'tap',answer:first,prompt:`Find the ${word(first)}.`,hint:'點選畫面中與這個步驟有關的物件。'};
 }
 return {type:'tap',answer:fallback.id,prompt:`Explore the ${fallback.word}.`,hint:s.number===2?'點引路物，看它先發光，再展開入口。':'找出這一幕的關鍵角色或道具，點選後觀察變化。'};
}
export function laterBook(key:LaterKey){
 const data=laterData[key],asset=`images/story/${key}-v1/`;
 const objects:Record<string,ObjectSpec>={},scenes:Record<string,SceneSpec>={};
 const layouts=data.scenes.map(s=>{const items=laterLayers(key,s);items.forEach(o=>objects[o.id]=o);const name=s.scene==='bedroom'?'bedroom':s.background.split('/').at(-1)!.replace('.png','');scenes[name]={name:s.scene==='bedroom'?'瑜瑜的星星房間':data.chineseTitle,caption:s.scene==='bedroom'?'GAIL’S BEDROOM':data.title,alt:s.title};return {items,name};});
 const pages=(level:ReadingLevel):StoryPage[]=>data.scenes.map((s,i)=>{const {items,name}=layouts[i];const text=bilingual(s,level);const focus=data.coreWords.filter(w=>new RegExp(`\\b${w}(?:s|es|ed|ing)?\\b`,'i').test(s.text[level].join(' ')));return {title:s.title,scene:name,lines:text.en,translation:text.zh.join('|'),words:focus.length?focus.slice(0,4):data.coreWords.filter(w=>new RegExp(`\\b${w}(?:s|es|ed|ing)?\\b`,'i').test(s.text.C.join(' '))).slice(0,3),objects:items.map(o=>o.id),placements:Object.fromEntries(items.map(o=>[o.id,o])),mission:mission(key,s,items),action:'explore'};});
 const questions=(level:ReadingLevel):StoryQuestion[]=>data.quiz.map((q,i)=>{
  let prompt=q.question,options=q.options,answer=q.answerIndex;
  if(level==='A'){prompt='What happens here?';const correct=data.scenes[q.scene-1].text.A.join(' ');options=[3,7,11].map(shift=>data.scenes[(q.scene-1+shift)%data.scenes.length].text.A.join(' '));answer=i%4;options.splice(answer,0,correct);}
  const correct=options[answer];
  const shown=options.filter((_,index)=>index!==answer);
  const position=answerPositions(key,level,data.quiz.length)[i]%options.length;
  shown.splice(position,0,correct);
  const scene=data.scenes[q.scene-1];return {id:`${key}-${level}-${i}`,kind:'choice',prompt,options:shown.map(text=>({text})),answer:[position],explanation:correct,imageAlt:scene.title,...(q.image?{image:q.image}:{sceneImage:{background:scene.background,assetBase:asset,objects:laterLayers(key,scene)}})};
 });
 return {key,title:data.title,chineseTitle:data.chineseTitle,asset,objects,scenes,pages,words:data.coreWords,questions,entries:data.vocabulary.map(v=>[v.word,v.chinese,'✦']),chinese:(page:number,level:ReadingLevel)=>bilingual(data.scenes[page],level).zh,choreography:(_level:ReadingLevel):Record<number,Record<number,StoryMotion[]>>=>({})};
}
export function laterCard(key:LaterKey,word:string){
 const item=laterData[key].vocabulary.find(v=>v.word===word);const wrap=document.createElement('div');wrap.className='layered-word-visual later-word-visual';if(!item)return wrap;
 const image=document.createElement('img');image.src=item.image;image.alt=item.chinese;
 const cue=document.createElement('span');cue.className='concept-cue';cue.textContent=item.cue;
 if(key==='picnic-counting'&&['one','two','three','four','five','six','seven','eight','nine','ten'].includes(word)){
  const count=laterData[key].coreWords.indexOf(word)+1;
  const grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(5,1fr);gap:5px;width:100%;align-items:center';
  for(let i=0;i<count;i++){const copy=image.cloneNode(true) as HTMLImageElement;copy.alt=`${i+1}`;copy.style.cssText='width:100%;height:70px;object-fit:contain';grid.append(copy);}
  wrap.append(grid,cue);
 }else wrap.append(image,cue);return wrap;
}
