import {laterData,type LaterKey} from './later-books';

/** Finite, sentence-triggered actions; all animation, particles and audio belong to this page. */
export function createLaterEffects(world:HTMLElement,key:LaterKey,page:number,soundEnabled:boolean){
 let disposed=false,paused=false,manual=false,generation=0,ctx:AudioContext|undefined;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const animations=new Set<Animation>(),particles=new Set<HTMLElement>(),sources=new Set<AudioScheduledSourceNode>();
 const scene=laterData[key].scenes[page],n=page+1;
 if(key==='journey-chances'&&[15,16].includes(n)){const bg=world.querySelector<HTMLElement>('.scene-bg');if(bg)bg.style.filter='brightness(.25) saturate(.55) hue-rotate(12deg)';}
 const get=(id:string)=>world.querySelector<HTMLElement>(`[data-object="${id}"]`);
 // Hide the doorway until the guide object has completed its invitation.
 if(n===2||n===20||key==='princess-weekend'){const door=get('portal');if(door)door.style.opacity='0';}
 if(key==='animal-sports-week'&&get('schedule')){
  const label=document.createElement('span');label.style.display='grid';label.innerHTML=['Monday','Tuesday','Wednesday','Thursday','Friday'].map(day=>`<span>${day}</span>`).join('');label.style.cssText='position:absolute;display:grid;grid-template-columns:repeat(5,1fr);gap:2px;left:7%;right:7%;top:35%;font-size:clamp(6px,.75vw,10px);color:#432e19;background:#fff4d9;white-space:normal;pointer-events:none';get('schedule')!.append(label);
 }
 if(key==='magic-tree-seasons'&&get('calendar')){
  const label=document.createElement('span');label.textContent=scene.objects.find(o=>o.id==='calendar')!.word;label.style.cssText='position:absolute;left:12%;right:12%;top:42%;font-size:clamp(10px,1.5vw,20px);font-weight:bold;color:#432e19;background:#fff4d9;pointer-events:none';get('calendar')!.append(label);
 }
 if(key==='picnic-counting'&&scene.mission?.type==='sequence'){
  scene.mission.steps?.forEach((id,index)=>{const node=get(id);if(!node)return;const badge=document.createElement('span');badge.textContent=String(index+1);badge.className='count-order';badge.style.cssText='position:absolute;right:0;top:0;border-radius:50%;background:#fff8df;color:#453321;font:bold 12px system-ui;width:20px;height:20px;line-height:20px;pointer-events:none';node.append(badge);});
 }
 if(key==='picnic-counting'){const cloth=get('blanket')?.querySelector('img');if(cloth)cloth.style.objectFit='fill';}
 const find=(prefix:string)=>scene.objects.find(o=>o.id.startsWith(prefix))?.id||prefix;
 function stopAudio(){sources.forEach(s=>{try{s.stop();}catch{}});sources.clear();}
 function clear(){generation++;animations.forEach(a=>a.cancel());animations.clear();particles.forEach(p=>p.remove());particles.clear();stopAudio();}
 function animateNode(node:HTMLElement,frames:Keyframe[],duration=1000){
  const a=node.animate(reduced?[{opacity:.8},{opacity:1}]:frames,{duration:reduced?160:duration,easing:'ease-in-out',fill:'forwards'});animations.add(a);if(paused)a.pause();return a.finished.catch(()=>{});
 }
 function animate(id:string,frames:Keyframe[],duration=1000){const node=get(id);return node&&!disposed?animateNode(node,frames,duration):Promise.resolve();}
 const glow=(id:string)=>animate(id,[{filter:'drop-shadow(0 0 0px #fff5c0)'},{filter:'drop-shadow(0 0 15px #fff0a3)'},{filter:'drop-shadow(0 0 3px #ffeeb5)'}],1100);
 const move=(id:string,x=0,y=0,rotate=0)=>animate(id,[{translate:'0 0',rotate:'0deg'},{translate:`${x}px ${y}px`,rotate:`${rotate}deg`},{translate:'0 0',rotate:'0deg'}],1300);
 function sound(kind:'glass'|'wood'|'wind'|'cloth'|'magic'|'machine'){
  if(!soundEnabled||paused||disposed)return;
  try{
   ctx??=new AudioContext();void ctx.resume();const t=ctx.currentTime,gain=ctx.createGain();gain.gain.setValueAtTime(.0001,t);gain.gain.linearRampToValueAtTime(.014,t+.04);gain.gain.exponentialRampToValueAtTime(.0001,t+.5);gain.connect(ctx.destination);
   let source:AudioScheduledSourceNode;
   if(kind==='wind'||kind==='cloth'){const noise=ctx.createBuffer(1,Math.floor(ctx.sampleRate*.6),ctx.sampleRate);const values=noise.getChannelData(0);for(let i=0;i<values.length;i++)values[i]=(Math.random()*2-1)*.35;const node=ctx.createBufferSource();node.buffer=noise;const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=kind==='wind'?600:1600;node.connect(filter).connect(gain);source=node;}
   else{const node=ctx.createOscillator();node.type=kind==='machine'?'triangle':'sine';node.frequency.setValueAtTime({glass:980,wood:220,magic:620,machine:340}[kind],t);node.frequency.exponentialRampToValueAtTime(kind==='magic'?920:160,t+.5);node.connect(gain);source=node;}
   sources.add(source);source.onended=()=>sources.delete(source);source.start(t);source.stop(t+.6);
  }catch{/* Device audio is optional. */}
 }
 function sparkle(id:string){
  const origin=get(id);if(!origin||reduced)return;
  const symbol=key==='magic-potion'?'❧':key==='palace-friend'?'✧':key==='little-robot'?'·':'✦';
  for(let i=0;i<9;i++){const dot=document.createElement('span');dot.textContent=symbol;dot.style.cssText=`position:absolute;pointer-events:none;z-index:8;color:#ffedb3;font-size:22px;left:${origin.style.left};top:${origin.style.top}`;world.append(dot);particles.add(dot);void animateNode(dot,[{opacity:0,translate:'0 0',scale:.4},{opacity:.9,offset:.3},{opacity:0,translate:`${(i-4)*18}px ${-35-(i%3)*22}px`,scale:1.1}],1000).then(()=>{dot.remove();particles.delete(dot);});}
 }
 async function sequence(ids:string[],token:number){for(const id of ids){if(disposed||token!==generation)return;await glow(id);}}
 async function portal(token:number){
  const guide=key==='princess-weekend'?'watch':key==='magic-potion'?'moonmint':key==='palace-friend'?'apron':scene.objects.some(o=>o.id==='guide')?'guide':find('ticket');
  const door=get('portal');if(door)door.style.opacity='0';
  await move(guide,0,-8,key==='palace-friend'?5:0);if(disposed||token!==generation)return;
  sparkle(guide);sound(key==='magic-potion'?'wind':key==='palace-friend'?'cloth':'magic');await glow(guide);if(disposed||token!==generation)return;
  if(door){door.style.opacity='1';await animate('portal',[{opacity:0,scale:.3},{opacity:1,scale:1}],1000);}
 }
 function act(line:number,id='',text=''){
  if(disposed)return;clear();const token=generation;
  if(key==='princess-weekend'){
   if([2,5,21,23].includes(n))return portal(token);
   if(n===1){void move('watch',0,-7);void glow('watch');sound('magic');return;}
   if(n===24){void animate('watch',[{filter:'drop-shadow(0 0 13px #ffde89)'},{filter:'none'}],1600);sound('wood');return;}
   const selected=scene.objects.find(o=>o.id===id);
   const target=selected?.id||(n===18?'clothes':n===19?'ella':n>=10&&n<=13?(n<=11?'meal':'dessert'):n>=7&&n<=9?'ticket':n===20?'watch':n===15?'ticket':'ella');
   void glow(target);
   if(['gail','ella'].includes(target))void move(target,0,2,1);
   else if(target==='ticket')void move(target,0,-5,-3);
   else if(target==='clothes')void move(target,0,-3,1);
   else if(target==='watch'){sparkle('watch');void move('watch',0,-5);}
   else if(target==='dessert'||target==='meal')void move(target,0,-3);
   sound(target==='watch'?'magic':target==='ticket'||target==='clothes'?'cloth':'wood');return;
  }
  const guide=key==='magic-potion'?'moonmint':key==='palace-friend'?'apron':'guide';
  if(n===2||n===19&&get('portal')){return portal(token);}
  if(n===1){void move(guide,0,-7,key==='little-robot'?22:5);sound(key==='palace-friend'?'cloth':'magic');return;}
  if(n===20&&get('portal'))return portal(token);
  if(n===20){void animate(guide,[{filter:'drop-shadow(0 0 12px #ffe4b0)'},{filter:'none'}]);return;}
  const speaker=scene.objects.find(o=>['gail','mira','ella','alice','teacher','keeper','curator','builder','robot','guest','rabbit','bear','otter','owl','fox','deer','badger','squirrel','hedgehog','gardener','lifeguard'].includes(o.id)&&new RegExp(`\\b${o.word}\\b`,'i').test(text));
  if(speaker)void move(speaker.id,0,2,1.5);
  const observed=scene.objects.find(o=>o.id===id)||scene.objects.find(o=>text.toLowerCase().includes(o.word.toLowerCase())&&o.id!=='gail');
  const target=observed?.id||scene.objects.find(o=>o.z!==3&&o.id!=='gail'&&o.id!=='portal')?.id||scene.objects.find(o=>o.id!=='gail')?.id||'gail';
  if(key==='journey-chances'){
   if(n===7){void move('ship',22,-9,1);sound('wind');}
   else if(n===11){void glow('taxi');sound('machine');}
   else if([13,15,16].includes(n)){void move('gail',8,-3);void move('mira',8,-3);void move('guide',8,-3);sound('cloth');}
   else if([17,18].includes(n)){void glow('gail');void glow('mira');sound('wind');}
   else{void glow(target);sound([4,5,6,9].includes(n)?'wind':'cloth');}
  }else if(key==='dragon-boat-festival'){
   if(get('boat-sailing')){void move('boat-sailing',n===17?-18:-8,n===5?5:-2,n===5?2:.4);sound('wind');}
   else if([9,10,11,12].includes(n)){void move('gail',0,2,2);void move('squirrel',0,2,2);void move('drum',0,2);sound('wood');}
   else{void glow(target);sound(n===19?'cloth':'wood');}
  }else if(key==='lost-lighthouse'){
   if([3,4,5,16,17].includes(n)){['boat1','boat2','boat3'].forEach((b,i)=>void move(b,n<6?8:22,-4-i));void glow(n<6?'wrong-beam':'correct-beam');sound('wind');}
   else if([9,11,12,13,14,15].includes(n)){void move(get('angle-arrow')?'angle-arrow':'model',0,0,n===13?9:-7);void glow('test-card');sound('glass');}
   else void glow(target);
  }else if(key==='mixed-up-museum'){
   if([4,5].includes(n)){void move('wrong-label-1',10,-5,9);void move('wrong-label-2',-10,-5,-9);sound('wind');}
   else if([7,8,11,16,17,18].includes(n))void sequence(scene.objects.filter(o=>!['gail','curator'].includes(o.id)).map(o=>o.id),token);
   else if(n===14){void move('record',0,-16);sound('wood');}
   else{void glow(target);sound('wood');}
  }else if(key==='bridge-construction'){
   if([6,7,8].includes(n)){void animate('tape',[{clipPath:'inset(0 70% 0 0)'},{clipPath:'inset(0 0 0 0)'}]);sound('wood');}
   else if(n===10){void move('model-bent',0,7,3);sound('wood');}
   else if([11,12,13,14].includes(n)){void glow(find('model'));sound('wood');}
   else if(n===17){void move('builder',-18,0);void glow('finished-bridge');}
   else void glow(target);
  }else if(key==='little-robot'){
   if([9,10,11,12,13].includes(n)){void sequence(['card-start','card-red','card-blue','card-yellow','card-stop',...(n===13?['button']:[])],token);sound('machine');}
   else if([14,15,17,18].includes(n)){void move('robot',-18,0);void sequence(scene.objects.filter(o=>o.id.startsWith('lantern')).map(o=>o.id),token);sound('machine');}
   else if(n===7){void move('gear',0,0,75);sound('machine');}
   else{void glow(target);sound('machine');}
  }else if(key==='magic-potion'){
   if(n===11){void move('mira',12,-18);void move('broom',12,-18);sound('wind');}
   else if([6,8,12].includes(n)){void sequence([find('recipe'),find('moonmint')],token);sound('wind');}
   else if(n===9){void move('moonmint0',35,-8);void glow('vial1');sound('glass');}
   else if(n===13){void move('crystal1',20,15);void glow('vial2');sound('glass');}
   else if(n===15){void move('mortar0',0,4,3);void move('vial1',-8,0,-10);sound('wood');}
   else if(n===16){sparkle('cauldron0');void glow('cloudy-vial1');sound('glass');}
   else if([14,17,18].includes(n)){void sequence([find('recipe'),find(n===17?'cloudy-vial':'vial')],token);if(n===18)sparkle('vial1');sound('glass');}
   else if(n===19){sparkle('vial0');void glow('vial0');sound('magic');}
   else{void glow(target);sound('wind');}
  }else if(key==='animal-sports-week'){
   if([5,6].includes(n)){void move('baseball',-22,-9);sound('wood');}
   else if([7,8].includes(n)){void move('basketball',24,8);sound('wood');}
   else if([9,10].includes(n)){void move('soccer',20,0,25);sound('wood');}
   else if([11,12].includes(n)){void move('football',24,-8,12);sound('wind');}
   else if([13,14,15,16].includes(n)){void move('otter',-18,1);sound('wind');}
   else void glow(target);
  }else if(key==='magic-tree-seasons'){
   void glow('calendar');if(line===0)sound('wind');
  }else if(key==='picnic-counting'){
   if([5,17].includes(n)){void move('kite1',7,-8,4);void move('kite2',-5,-9,-4);sound('wind');}
   else {void glow(target);if(line===0)sound('cloth');}
  }else{
   if(n===5){void move('alice',0,5,7);void move('ella',0,8);sound('cloth');}
   else if(n===9){void animate('napkin0',[{translate:'0 -40px',rotate:'-10deg'},{translate:'0 0',rotate:'7deg'}]);sound('cloth');}
   else if(n===10){void move('napkin0',0,-22);void move('gail',5,5,4);sound('cloth');}
   else if(n===13){void move('gail',0,6,4);void glow('alice');}
   else if([14,15,16].includes(n)){void sequence(['alice','guest'],token);if(n===16)void move('fruit1',20,-10);sound('cloth');}
   else if([18,19].includes(n)){void animate('pinwheel0',[{rotate:'0deg'},{rotate:'180deg'},{rotate:'360deg'}],2300);sound('wind');}
   else{void glow(target);if(line===0)sound('cloth');}
  }
 }
 return {interact(id:string){manual=true;paused=false;act(0,id);},sentence(index:number,text:string){manual=false;return act(index,'',text);},playback(running:boolean,isPaused:boolean){paused=isPaused||(!running&&!manual);animations.forEach(a=>{if(paused&&a.playState==='running')a.pause();else if(!paused&&a.playState==='paused')a.play();});if(ctx)void(paused?ctx.suspend():soundEnabled?ctx.resume():ctx.suspend());},sound(on:boolean){soundEnabled=on;if(!on){stopAudio();void ctx?.suspend();}},dispose(){disposed=true;clear();void ctx?.close();}};
}
