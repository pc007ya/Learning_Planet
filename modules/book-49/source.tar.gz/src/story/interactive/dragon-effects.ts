/** The gold scale opens the fixed bedroom into Pip's forest; all effects belong to one page. */
export function createDragonEffects(world:HTMLElement,page:number,lineCount:number,soundEnabled:boolean){
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const animations=new Set<Animation>();
 const nodes=new Set<HTMLElement>();
 const timers=new Set<ReturnType<typeof setTimeout>>();
 let disposed=false,manual=false,isPaused=false,audio:AudioContext|undefined;
 const scale=()=>world.querySelector<HTMLElement>('[data-object="scale"]');
 function animate(node:HTMLElement,frames:Keyframe[],duration:number,delay=0){
  const a=node.animate(frames,{duration:reduced?220:duration,delay:reduced?0:delay,easing:'ease-in-out',fill:'forwards'});
  animations.add(a);void a.finished.finally(()=>animations.delete(a)).catch(()=>{});return a;
 }
 function later(delay:number,fn:()=>void){const timer=setTimeout(()=>{timers.delete(timer);if(disposed)return;if(isPaused){later(100,fn);return;}fn();},reduced?0:delay);timers.add(timer);}
 function removeEffects(){for(const timer of timers)clearTimeout(timer);timers.clear();for(const a of animations)a.cancel();animations.clear();for(const n of nodes)n.remove();nodes.clear();}
 function chime(){
  if(!soundEnabled||disposed)return;
  try{audio??=new AudioContext();if(audio.state==='suspended')void audio.resume().catch(()=>{});
   const oscillator=audio.createOscillator(),gain=audio.createGain(),at=audio.currentTime;
   oscillator.type='sine';oscillator.frequency.setValueAtTime(784,at);oscillator.frequency.exponentialRampToValueAtTime(1047,at+.25);
   gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.024,at+.03);gain.gain.exponentialRampToValueAtTime(.0001,at+.55);
   oscillator.connect(gain).connect(audio.destination);oscillator.start(at);oscillator.stop(at+.56);
  }catch{/* The visual transition remains available without audio. */}
 }
 function drift(){const target=scale();if(!target)return;
  animate(target,[{translate:'38px -60px',rotate:'-24deg',opacity:.35},{translate:'0 0',rotate:'8deg',opacity:1}],reduced?220:1300);
 }
 function sparks(){const host=scale();if(!host)return;
  animate(host,[{filter:'drop-shadow(0 0 2px #ffd778)'},{filter:'drop-shadow(0 0 24px #fff2a7)',offset:.4},{filter:'drop-shadow(0 0 9px #f4bb5c)'}],reduced?220:1700);
  chime();
  for(let i=0;i<16;i++){
   const dot=document.createElement('i');dot.className='dragon-scale-spark';dot.setAttribute('aria-hidden','true');
   dot.style.left='50%';dot.style.top='50%';host.append(dot);nodes.add(dot);
   const angle=(i/16)*Math.PI*2,distance=45+(i%4)*31;
   animate(dot,[{opacity:0,translate:'0 0',scale:.3},{opacity:.95,offset:.28},{opacity:0,translate:`${Math.cos(angle)*distance}px ${Math.sin(angle)*distance}px`,scale:1.5}],reduced?220:1500,i*55);
  }
 }
 function reveal(){if(world.querySelector('.dragon-forest-arrival'))return;
  const arrival=document.createElement('div');arrival.className='dragon-forest-arrival';arrival.setAttribute('aria-hidden','true');arrival.style.backgroundImage='url(images/story/dragon-v1/scenes.png)';world.append(arrival);nodes.add(arrival);
  animate(arrival,[{opacity:0},{opacity:1}],reduced?220:1250);
 }
 function interact(id:string){if(page!==0||id!=='scale'||disposed)return;
  manual=true;isPaused=false;removeEffects();drift();later(450,sparks);later(1650,reveal);
 }
 return {
  interact,
  sentence(index:number,_text:string){if(page!==0||disposed)return;if(index===0){manual=false;removeEffects();drift();}
   if(index===1)sparks();if(index===lineCount-1){if(lineCount===2)later(950,reveal);else reveal();}},
  playback(running:boolean,paused:boolean){if(disposed)return;
   const stop=paused||!running&&!manual;
   isPaused=stop;
   for(const a of animations){if(stop&&a.playState==='running')a.pause();else if(!stop&&a.playState==='paused')a.play();}
   if(stop&&audio?.state==='running')void audio.suspend().catch(()=>{});
   if(!stop&&audio?.state==='suspended')void audio.resume().catch(()=>{});
  },
  sound(enabled:boolean){soundEnabled=enabled;if(!enabled&&audio?.state==='running')void audio.suspend().catch(()=>{});},
  dispose(){disposed=true;removeEffects();if(audio){void audio.close().catch(()=>{});audio=undefined;}}
 };
}
