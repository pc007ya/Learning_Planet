import type {ProductionKey} from './production-four-content';

/** Each effect belongs to one page and is cancelled when that page closes. */
export function createProductionEffects(world:HTMLElement,book:ProductionKey,page:number,soundEnabled:boolean){
 let disposed=false,paused=false,manual=false,ctx:AudioContext|undefined;
 const animations=new Set<Animation>(),tasks=new Set<ReturnType<typeof setTimeout>>(),tones=new Set<OscillatorNode>();
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const get=(id:string)=>world.querySelector<HTMLElement>(`[data-object="${id}"]`);
 const animate=(id:string,frames:Keyframe[],duration=1200)=>{const n=get(id);if(!n||disposed)return;const a=n.animate(reduced?[{opacity:.7},{opacity:1}]:frames,{duration:reduced?180:duration,easing:'ease-in-out',fill:'forwards'});animations.add(a);a.onfinish=()=>animations.delete(a);if(paused)a.pause();};
 const later=(fn:()=>void,delay:number)=>{const t=setTimeout(()=>{tasks.delete(t);if(!disposed&&!paused)fn();},delay);tasks.add(t);};
 const sound=(frequency=600)=>{if(!soundEnabled||paused||disposed)return;ctx??=new AudioContext();void ctx.resume();const tone=ctx.createOscillator(),gain=ctx.createGain(),time=ctx.currentTime;tone.type='sine';tone.frequency.setValueAtTime(frequency,time);tone.frequency.linearRampToValueAtTime(frequency*1.23,time+.2);gain.gain.setValueAtTime(.0001,time);gain.gain.linearRampToValueAtTime(.012,time+.03);gain.gain.exponentialRampToValueAtTime(.0001,time+.38);tone.connect(gain).connect(ctx.destination);tones.add(tone);tone.onended=()=>tones.delete(tone);tone.start();tone.stop(time+.4);};
 const stop=()=>{tasks.forEach(clearTimeout);tasks.clear();animations.forEach(a=>a.cancel());animations.clear();tones.forEach(t=>{try{t.stop();}catch{}});tones.clear();};
 const glow=(id:string)=>animate(id,[{filter:'drop-shadow(0 0 0px #fff2b2)'},{filter:'drop-shadow(0 0 14px #ffde73)'},{filter:'drop-shadow(0 0 2px #fff2b2)'}],1600);
 function act(line:number,id=''){
  if(disposed)return;stop();
  const guide=book.startsWith('snow')?'guide':book==='magic-ball'?'ball':'guide';
  if(page===0){animate(guide,[{translate:'-36px 0',rotate:'-22deg'},{translate:'0 0',rotate:'0deg'}],700);later(()=>sound(book.startsWith('snow')?820:620),740);return;}
  if(page===1){
   animate('portal',[{opacity:0,scale:.3},{opacity:0,scale:.3}],650);
   later(()=>{glow(guide);sound(book.startsWith('snow')?900:720);},700);
   later(()=>animate('portal',[{opacity:0,scale:.3},{opacity:1,scale:1}],1000),1000);return;
  }
  const target=id||world.querySelector<HTMLElement>('[data-object]:not([data-object="gail"])')?.dataset.object||'gail';
  if(book==='market'){
   if([3,7].includes(page)){['card','card2'].forEach((name,i)=>animate(name,[{translate:'0 0',rotate:'0deg'},{translate:`${i?20:-22}px -14px`,rotate:i?'13deg':'-12deg'},{translate:'0 0',rotate:'0deg'}],1700));sound(430);}
   else if([8,9,12,13,14,15].includes(page)){glow(page===9?'order':'card');sound(650);}
   else if(page===16){animate('coin',[{translate:'-30px -18px'},{translate:'22px 10px'}],900);sound(540);}
   else glow(target);
  }else if(book==='magic-ball'){
   if([5,6].includes(page)){animate('ball',[{translate:'-20px 0'},{translate:'20px -15px'},{translate:'-16px 5px'},{translate:'0 0'}],1700);sound(400);}
   else if([7,16].includes(page)){glow('card');sound(480);}
   else if([12,13,15,17].includes(page)){animate('ball',[{translate:'-22px 0'},{translate:'18px -16px'},{translate:'40px 0'}],1300);glow('hoop');sound(730);}
   else glow(target);
  }else{
   if(book==='snow-before'&&page===17||book==='snow-after'&&page<=2){glow('guide');sound(840);}
   else if(book==='snow-after'&&[4,6,7,15].includes(page)){glow('sign');sound(420);}
   else if(book==='snow-after'&&[12,13].includes(page)){animate(page===13?'snowman':'snowball',[{translate:'0 0'},{translate:'10px -10px'},{translate:'0 0'}],1100);sound(680);}
   else glow(target);
  }
  if(line>0&&page!==19)animate('gail',[{translate:'0 0'},{translate:'3px 0'},{translate:'0 0'}],1300);
 }
 return {interact(id:string){manual=true;act(1,id);},sentence(index:number,_text:string){manual=false;act(index);},playback(running:boolean,isPaused:boolean){paused=isPaused||(!running&&!manual);animations.forEach(a=>paused?a.pause():a.play());if(ctx)void(paused?ctx.suspend():ctx.resume());},sound(on:boolean){soundEnabled=on;if(!on)void ctx?.suspend();},dispose(){disposed=true;stop();void ctx?.close();}};
}
