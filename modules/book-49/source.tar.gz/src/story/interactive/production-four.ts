import type {ObjectSpec,SceneSpec,StoryPage} from './book';
import type {ReadingLevel} from './dragon-text';
import type {StoryQuestion} from './dragon-quiz';
import type {StoryMotion} from './choreography';
import {productionContent,type ProductionKey} from './production-four-content';
import {translatedPage} from './production-four-translations';

export const productionBookFromPath=(path:string):ProductionKey|undefined=>(['market','magic-ball','snow-before','snow-after'] as const).find(key=>path.endsWith(`/${key}-storybook.html`));
const images:Record<ProductionKey,Record<string,string>>={
 market:{'apple-left':'apples.png','apple-right':'apples.png',table:'../time-v1/table.png',beef:'beef.png',pork:'pork.png',rice:'rice.png',salad:'salad.png',gail:'../shared-gail-v1/standing.png',worker:'worker.png',customer:'customer.png',guide:'guide.png',portal:'portal.svg',card:'card.png',card2:'card2.png',order:'order.png',basket:'basket.png',apples:'apples.png',grapes:'grapes.png',coin:'coin.png',tray:'tray.png'},
 'magic-ball':{gail:'../shared-gail-v1/standing.png',mira:'mira-standing.png',friend:'friend.png',teacher:'teacher.png',guide:'broomstick.png',portal:'portal.svg',ball:'ball.svg',card:'rule-card.svg',hoop:'hoop.svg',cushion:'cushion.png'},
 'snow-before':{gail:'../shared-gail-v1/standing.png',friend:'friend.png',neighbor:'neighbor.png',worker:'worker.png',guide:'guide-snow.svg',portal:'portal.svg',basket:'basket.svg',apples:'apples.svg',grapes:'grapes.svg',wagon:'wagon.svg',barrel:'barrel.svg',juice:'juice.png',tray:'tray-fruit.svg',jars:'jars.svg',box:'box.svg',house:'house.svg',wood:'wood.svg',card:'rule-card.svg'},
 'snow-after':{gail:'../shared-gail-v1/standing.png',friend:'friend.png',neighbor:'neighbor.png',worker:'worker.png',guide:'guide-snow.svg',portal:'portal.svg',basket:'basket.svg',sign:'sign.svg',ice:'ice.svg',shovel:'shovel.svg',snowbank:'snowbank.svg',soup:'soup.svg',snowball:'snowball.svg',snowman:'snowman.png',sun:'sun.svg',house:'house.svg',jars:'jars.svg'}
};
const captions:Record<ProductionKey,string>={market:'ASK, CHECK, AGREE','magic-ball':'A RULE WE MAKE TOGETHER','snow-before':'READY BEFORE THE SNOW','snow-after':'CARE FIRST, THEN PLAY'};
const placing=(key:ProductionKey,scene:string,id:string,index:number,total:number):ObjectSpec=>{
 const actor=['gail','worker','customer','mira','friend','teacher','neighbor'].includes(id);
 const positions:Record<string,[number,number,number,number]>={gail:[22,72,27,52],worker:[80,65,25,62],customer:[54,72,24,51],mira:[54,72,27,53],friend:[60,72,25,52],teacher:[85,64,23,65],neighbor:[80,72,26,55]};
 let [x,y,w,h]=positions[id]||[45+index*14,77-index*3,17,19];
 if(scene==='bedroom'&&id==='gail'){[x,y,w,h]=[34,77,33,42];}
  if(key==='magic-ball'&&id==='friend'){[x,y,w,h]=[78,72,23,50];}
 if(key.startsWith('snow')&&id==='worker'){[x,y,w,h]=[83,69,23,56];}
 if(key==='snow-after'&&id==='friend'&&scene==='field'){[x,y,w,h]=[81,72,25,52];}
 const special:Record<string,[number,number,number,number]>={guide:[57,83,13,15],portal:[73,51,36,70],ball:[50,77,17,21],hoop:[67,52,25,46],cushion:[65,89,34,16],card:[45,78,19,24],card2:[66,78,18,23],order:[48,75,22,26],basket:[53,84,21,20],apples:[47,80,18,20],grapes:[63,80,18,20],coin:[52,80,13,16],tray:[66,86,22,15],wagon:[52,82,32,24],barrel:[73,80,20,28],juice:[48,80,15,22],jars:[54,80,20,26],box:[62,82,22,22],house:[70,69,26,40],wood:[65,85,22,16],sign:[47,76,20,35],ice:[67,88,22,15],shovel:[71,76,16,31],snowbank:[57,88,35,19],soup:[52,83,19,20],snowball:[55,84,18,19],snowman:[58,73,24,40],sun:[70,22,15,21]};
 if(!actor){[x,y,w,h]=special[id]||[x,y,w,h];if(scene==='bedroom'&&id==='guide'){[x,y,w,h]=[58,82,13,15];}if(scene==='bedroom'&&id==='ball'){[x,y,w,h]=[66,82,14,17];}}
 if(!actor&&total>2&&!['portal','hoop','cushion'].includes(id))x=Math.min(83,x+(index-1)*6);
 if(key==='snow-after'&&id==='snowman'){[x,y,w,h]=[56,77,25,37];}
 // The food dishes form a low foreground display, below the characters' faces.
 if(key==='market'&&['beef','pork','rice','salad'].includes(id)){[x,y,w,h]=[25+['beef','pork','rice','salad'].indexOf(id)*18,77,17,16];}
 if(key==='market'&&id==='table'){[x,y,w,h]=[52,97,85,64];}
 return {id,word:id==='guide'?'magic':id==='gail'?'Gail':id,x,y,w,h,z:actor||id==='table'?3:id==='portal'?1:4,image:images[key][id]};
};

export function productionBook(key:ProductionKey){
 const data=productionContent[key];const asset=`images/story/${key}-v1/`;
 const words=data.words.split(' '),glosses=data.glosses.split(' ');
 const objects:Record<string,ObjectSpec>={};
 const layouts=data.rows.map((row,i)=>{
  const ids=[...new Set([...row.cast,...row.props,...(key==='market'&&row.props.includes('basket')?['apple-left','apple-right']:[])])];
  const items=ids.map(id=>{
   const actor=row.cast.includes(id);const index=actor?row.cast.indexOf(id):row.props.indexOf(id);
   const spec=placing(key,row.scene,id,index,actor?row.cast.length:row.props.length);
   if(id==='gail'&&row.scene==='bedroom')spec.image='../shared-gail-v1/kneeling-clean-v2.png';
   if(id==='gail'&&key==='market'&&i===8)spec.image='../shared-gail-v1/reaching.png';
   if(key.startsWith('snow')&&id==='guide'&&row.scene==='bedroom'){[spec.x,spec.y,spec.w,spec.h]=[61,49,12,15];}
  if(key==='snow-before'&&id==='guide'&&i===17){[spec.x,spec.y,spec.w,spec.h]=[34,52,11,14];}
  if(key==='market'){
   const hasOrder=row.props.includes('order');
   if(id==='basket'){[spec.x,spec.y,spec.w,spec.h]=[65,85,22,22];}
   if(id==='card'){[spec.x,spec.y,spec.w,spec.h]=[hasOrder?57:42,hasOrder?62:73,14,20];}
   if(id==='card2'){[spec.x,spec.y,spec.w,spec.h]=[86,73,14,20];}
   if(id==='order'){[spec.x,spec.y,spec.w,spec.h]=[38,72,19,25];}
   if(id==='apple-left'||id==='apple-right'){
    [spec.x,spec.y,spec.w,spec.h]=[id==='apple-left'?62:68,78,5,7];spec.word='apple';spec.z=5;
   }
  }
  if(key==='market'&&id==='guide'&&i===19){[spec.x,spec.y,spec.w,spec.h]=[75,51,9,12];}
  if(key==='market'&&id==='card'&&i===17){[spec.x,spec.y,spec.w,spec.h]=[52,64,12,16];}
  if(key==='market'&&id==='coin'&&i===16){[spec.x,spec.y,spec.w,spec.h]=[66,78,12,15];}
  if(key==='snow-after'&&id==='neighbor'&&i===18){[spec.x,spec.y,spec.w,spec.h]=[92,40,10,17];}
  if(key==='magic-ball'&&id==='ball'){
   const ballPositions:Record<number,[number,number,number,number]>={0:[68,84,14,17],1:[65,76,16,19],3:[53,77,16,19],4:[61,76,16,19],5:[38,68,16,19],6:[77,73,15,18],7:[58,83,16,19],8:[48,80,15,18],10:[53,66,15,18],11:[73,77,15,18],12:[40,62,15,18],13:[38,75,15,18],14:[58,70,15,18],15:[69,57,14,17],16:[47,78,15,18],17:[70,57,14,17],18:[45,81,15,18],19:[70,84,14,17]};
   if(ballPositions[i])[spec.x,spec.y,spec.w,spec.h]=ballPositions[i];
  }
  if(key==='magic-ball'&&id==='gail'&&[12,13,15,17].includes(i))spec.image='../shared-gail-v1/reaching.png';
   return spec;
  });
  items.forEach(o=>objects[o.id]={...o});return items;
 });
 const scenes:Record<string,SceneSpec>={};
 data.rows.forEach(row=>{scenes[row.scene]={name:row.scene==='bedroom'?'瑜瑜的星星房間':data.chineseTitle,caption:row.scene==='bedroom'?'GAIL’S BEDROOM':captions[key],alt:row.scene==='bedroom'?'固定的星星房間':`${data.chineseTitle}：${row.scene}背景`};});
 const pages=(level:ReadingLevel):StoryPage[]=>data.rows.map((row,i)=>{
  const items=layouts[i].map(o=>({...o}));const answer=row.props[0]||row.cast.find(id=>id!=='gail')||'gail';
  return {title:row.title,scene:row.scene,lines:row[level].split('|'),translation:translatedPage(key,i,level,row.zh).join('|'),words:row.focus,objects:items.map(o=>o.id),placements:Object.fromEntries(items.map(o=>[o.id,o])),mission:{type:'tap',answer,prompt:`Find ${answer}.`,hint:'點一點畫面中的獨立道具或角色，聽聽它的名字。'},action:'explore'};
 });
 const questionPages=[0,2,3,4,5,6,7,9,10,11,12,13,14,15,16,18];
 const questions=(level:ReadingLevel):StoryQuestion[]=>questionPages.map((sceneIndex,i)=>{
  const story=pages(level)[sceneIndex],row=data.rows[sceneIndex];
  const distractorIndices=[(sceneIndex+5)%20,(sceneIndex+9)%20,(sceneIndex+13)%20];
  const clean=(n:number)=>data.rows[n].A.split('|')[0];const correct=clean(sceneIndex);
  const options=distractorIndices.map(n=>clean(n));options.splice(i%4,0,correct);
  return {id:`${key}-${i}`,kind:'choice',sceneImage:{background:story.scene==='bedroom'?'images/story/shared-gail-v1/bedroom.png':asset+story.scene+'.png',assetBase:asset,objects:story.objects.map(id=>({...objects[id],...story.placements?.[id]}))},imageAlt:row.title,prompt:level==='A'?'What happens here?':'Which event matches this picture?',options:options.map(text=>({text})),answer:[i%4],explanation:correct};
 });
 return {key,title:data.title,chineseTitle:data.chineseTitle,asset,objects,scenes,pages,words,questions,entries:words.map((word,i)=>[word,glosses[i],'✦']),chinese:(page:number,level:ReadingLevel)=>translatedPage(key,page,level,data.rows[page].zh),choreography:(_level:ReadingLevel):Record<number,Record<number,StoryMotion[]>>=>({})};
}
