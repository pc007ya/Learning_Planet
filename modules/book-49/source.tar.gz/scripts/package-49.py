from pathlib import Path
import json,shutil,html,re
R=Path(__file__).resolve().parents[1];F=R.parent/'英文繪本/49.瑜瑜與公主喘息的假日';E=F/'ebook';Y=F/'youtube';D=R/'docs/story-plans/book-49';m=json.loads((E/'scene-manifest.json').read_text())
css=(R/'modules/book-49/reader.css').read_text();js=(R/'modules/book-49/reader.js').read_text().replace('</script','<\\/script');title=html.escape(m['title'])
page=f'<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>{css}</style><body data-story="princess-weekend" data-shelf-url="https://learnplanet.win/story-planet.html"><main id="little-star"></main><script>{js}</script></body></html>'
for name in ['index.html','princess-weekend-storybook.html']:(E/name).write_text(page)
paths={s['background'] for s in m['scenes']}|{i['image'] for s in m['scenes'] for i in s['objects']}|{v['image'] for v in m['vocabulary']}|{q['image'] for q in m['quiz']}|{'images/story/princess-weekend-v1/cover.png','images/story/shared-gail-v1/bedroom.png','images/brand/learning-planet-brand-v1.png'}
for rel in paths:
 assert (R/rel).is_file(),rel
 for dest in [E,Y/'layers']:
  p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,p)
(E/'vocabulary.json').write_text(json.dumps(m['vocabulary'],ensure_ascii=False,indent=2));(Y/'layered-scenes.json').write_text(json.dumps(m['scenes'],ensure_ascii=False,indent=2))
(E/'story-planet.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=https://learnplanet.win/story-planet.html"><a href="https://learnplanet.win/story-planet.html">回故事星球</a>')
(E/'README.md').write_text('# 第49本正式閱讀器\n\n開啟index.html，24幕ABC中英課文、21張單字卡、每級16題圖片測驗、物件互動及懷錶轉場。程式與圖片隨包附上；裝置語音的離線可用性取決於系統語音。回故事星球需網路。\n\n第18幕百貨公司才換現代衣服，第24幕換回睡衣。第5張quiz圖片為使用者確認原檔。\n\n分級設計目標B BR–100L／C 190L–530L，未實測Lexile。\n\n重建：build-49-reader.py → vite.book-49.config.ts → package-49.py。\n')
(Y/'frames').mkdir(exist_ok=True)
for s in m['scenes']:
 layers=f'<img class="bg" src="../layers/{s["background"]}" alt="">'
 for v in sorted(s['objects'],key=lambda v:v['z']):
  if v['id']=='portal':continue # initial frame; effects are specified separately
  layers+=f'<img src="../layers/{v["image"]}" alt="{html.escape(v["word"])}" style="left:{v["x"]}%;top:{v["y"]}%;width:{v["w"]}%;height:{v["h"]}%;transform:translate(-50%,-50%)'+(' scaleX(-1)' if v.get('flip') else '')+'">'
 frame='<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:#152638}main{position:relative;width:100vw;aspect-ratio:3/2}img{position:absolute;object-fit:contain}.bg{width:100%;height:100%;object-fit:cover}</style><main>'+layers+'</main>'
 (Y/f'frames/scene-{s["number"]:02}.html').write_text(frame)
# C-only handoff: speech timing stays explicitly estimated until recorded audio exists.
def duration(text):return round(max(5,len(re.findall(r"[A-Za-z]+(?:[’'-][A-Za-z]+)*",text))/125*60),2)
clips=[{'type':'opening','en':m['title'],'zh':m['chineseTitle'],'seconds':max(5,duration(m['title'])),'targetSeconds':5}]
for s in m['scenes']:clips.append(dict(type='scene',number=s['number'],en=' '.join(s['text']['C']),zh=''.join(s['chinese']['C']),seconds=duration(' '.join(s['text']['C'])),frame=f'frames/scene-{s["number"]:02}.html',visual=s['visual']))
clips.append({'type':'hold','seconds':3})
for q in m['quiz']:
 ext=Path(q['image']).suffix;dest=Y/f'quiz/assets/question-{q["number"]:02}{ext}';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/q['image'],dest)
 clips.extend([dict(type='quiz-question',number=q['number'],en=q['question'],seconds=duration(q['question']),image=str(dest.relative_to(Y))),dict(type='answer-wait',seconds=6),dict(type='bell',seconds=1.2),dict(type='answer',en=q['answer'],seconds=duration(q['answer'])),dict(type='hold',seconds=1)])
clips.append({'type':'ending-hold','seconds':3});t=0
for c in clips:c['start']=round(t,2);t+=c['seconds'];c['end']=round(t,2)
(Y/'timeline-C.json').write_text(json.dumps({'timing':'estimated; no generated audio','clips':clips},ensure_ascii=False,indent=2));(Y/'TTS-worklist-C.json').write_text(json.dumps([c for c in clips if c.get('en')],ensure_ascii=False,indent=2));(Y/'quiz-C.json').write_text(json.dumps({'level':'C','questions':m['quiz']},ensure_ascii=False,indent=2))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
subs=[]
for c in clips:
 if c.get('en'):subs.append(f'{len(subs)+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["en"]}'+('\n'+c['zh'] if c.get('zh') else '')+'\n')
(Y/'subtitles-C-estimated.srt').write_text('\n'.join(subs))
(Y/'README.md').write_text('# 第49本C級影片交接\n\n24幕C中英稿見C-script.md，分層素材見layers/及layered-scenes.json。frames/為逐幕原比例靜態HTML畫面，供對照圖層；懷錶轉場依正式閱讀器重播。6張quiz原生圖片保留，百貨公司為使用者確認原檔。\n\n只提供C級工作清單；未生成TTS／MP4。timeline-C.json、subtitles-C-estimated.srt均為預估，須按實際錄音重新對齊。片頭完整書名目標5秒；故事後停3秒，題目唸完等6秒，清音鈴一次，再揭示朗讀正解，停1秒換题，結尾停3秒。不唸選項。\n\n原圖不預留字幕區；Antigravity後製延伸背景與中英字幕。\n')
(D/'release-assets.json').write_text(json.dumps(sorted(paths),indent=2));print('Self-contained ebook, 24 frames, C timing/subtitles and quiz package saved.')
