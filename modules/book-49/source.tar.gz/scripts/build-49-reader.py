"""Book 49: approved 24-scene story, ABC reading text, independent layers, native quiz art."""
from pathlib import Path
import json, shutil
R=Path(__file__).resolve().parents[1];D=R/'docs/story-plans/book-49';F=R.parent/'英文繪本/49.瑜瑜與公主喘息的假日';P=R/'images/story/princess-weekend-v1';P.mkdir(parents=True,exist_ok=True)
o=json.loads((D/'scenes.json').read_text()); key='princess-weekend'
AB='''A watch! Tick, tick!|一只懷錶！滴答，滴答！|Gail is in her room. A golden watch opens and shines.|瑜瑜在房間裡，金色懷錶打開並發光。
The watch glows. Hello, Ella!|懷錶發光了。你好，Ella！|Light rises from the watch. Gail steps through a door to Ella.|光從懷錶升起，瑜瑜穿過門去找Ella。
Ella is busy.|Ella很忙。|Ella is busy in her castle. She wants to see the world.|Ella在城堡裡很忙，她想看看外面的世界。
A weekend break! That is nice.|週末休個假！真好。|Gail has a nice plan. They can take a weekend break.|瑜瑜有個好計畫，她們可以在週末休假。
Hold my hand. Let us go!|牽著我的手，出發吧！|The watch opens a door. Gail and Ella go through it together.|懷錶打開門，瑜瑜與Ella一起穿過門。
We are in the UK!|我們在英國！|They are in London, in the UK. Ella sees a red bus.|她們在英國倫敦，Ella看見紅色公車。
It is Saturday.|今天是星期六。|It is Saturday. Gail and Ella will see a movie.|今天星期六，瑜瑜與Ella要去看電影。
A movie theater!|一間電影院！|They go to a big movie theater. Ella looks at the poster.|她們來到大電影院，Ella看著海報。
We can talk. I am glad.|我們可以聊聊，我很開心。|The movie ends. They talk about the story together.|電影結束，她們一起聊電影的故事。
We are hungry. A restaurant!|我們餓了，一間餐廳！|They are hungry. They find a restaurant and look at the menu.|她們餓了，找到餐廳，一起看菜單。
French fries and coke!|薯條和可樂！|They have French fries and coke. The fries taste good.|她們吃薯條、喝可樂，薯條很好吃。
Lemon or banana ice cream?|檸檬還是香蕉冰淇淋？|Gail wants lemon ice cream. Ella wants banana ice cream.|瑜瑜想吃檸檬冰淇淋，Ella想吃香蕉冰淇淋。
It tastes good!|真好吃！|They taste their ice cream. Later, they go back to rest.|她們品嚐冰淇淋，稍後回住宿處休息。
It is Sunday. Shopping!|今天星期日，去逛街！|It is Sunday morning. They get ready to go shopping.|星期日早上，她們準備去逛街。
A train! We go underground.|一列火車！我們走進地下。|They take the Underground in London. Gail thinks of the MRT at home.|她們搭倫敦地鐵，瑜瑜想起家鄉的MRT。
A department store!|一間百貨公司！|They go to a big department store. There are many clothes.|她們到大百貨公司，裡面有好多衣服。
A cute T-shirt!|可愛的T恤！|Ella finds a cute T-shirt. It has a little star.|Ella找到可愛的T恤，上面有小星星。
A shirt. Pants. New clothes!|襯衫、長褲、新衣服！|Ella tries a shirt and pants. Gail changes out of her pajamas here, too.|Ella試穿襯衫和長褲，瑜瑜也在這裡換下睡衣。
You look cute, Ella!|Ella，你好可愛！|Ella wears a T-shirt and pants. Gail says she looks really cute.|Ella穿T恤與長褲，瑜瑜說她真的好可愛。
Time to go home.|該回家了。|The weekend is ending. Gail takes out the golden watch.|週末快結束，瑜瑜拿出金色懷錶。
Back at the castle! Thank you!|回到城堡！謝謝！|Light rises from the watch. They step through a door to the castle.|光從懷錶升起，她們穿門回城堡。
Maybe next time. Bye!|也許下次吧，再見！|Maybe Alice can come next time. Gail and Ella say bye.|也許Alice下次可以一起來，瑜瑜與Ella說再見。
Bye, Ella. I am going home.|再見Ella，我要回家了。|The same watch opens a door to Gail’s room. Ella waves from the castle.|同一只懷錶打開通往瑜瑜房間的門，Ella在城堡揮手。
My pajamas. My room. Tick, tick.|我的睡衣、我的房間。滴答，滴答。|Gail puts on her star pajamas at home. The watch rests beside her bed.|瑜瑜回家換回星星睡衣，懷錶放在床邊。'''
levels=[dict(zip(['A','AZ','B','BZ'],line.split('|'))) for line in AB.splitlines()];assert len(levels)==24
(D/'reading-levels.json').write_text(json.dumps(levels,ensure_ascii=False,indent=2))
refs={'bedroom':'shared-gail-v1/bedroom.png','gail-home':'shared-gail-v1/kneeling-clean-v2.png','gail-pajamas':'shared-gail-v1/standing.png','ella':'palace-friend-v1/ella.png','palace':'palace-friend-v1/hall.png','watch':'time-v1/watch.png','ticket':'painted-props-v2/museum-ticket.png'}
for name,src in refs.items():shutil.copy2(R/'images/story'/src,P/f'{name}.png')
shutil.copy2(D/'cover.png',P/'cover.png')
# A programmable portal is an effect, not a physical prop.
(P/'portal.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="500" height="700" viewBox="0 0 500 700"><defs><radialGradient id="g"><stop stop-color="#fffde7" stop-opacity=".75"/><stop offset=".75" stop-color="#fce697" stop-opacity=".2"/><stop offset="1" stop-color="#ffd571" stop-opacity="0"/></radialGradient></defs><ellipse cx="250" cy="350" rx="240" ry="330" fill="url(#g)"/><ellipse cx="250" cy="350" rx="210" ry="300" fill="none" stroke="#ffe8a4" stroke-width="8"/></svg>')
def obj(id,file,x,y,w,h,z=3,word=None,flip=False):return dict(id=id,word=word or id,image=f'images/story/{key}-v1/{file}',x=x,y=y,w=w,h=h,z=z,flip=flip)
def pair(modern=False):return [obj('gail','gail-modern.png' if modern else 'gail-pajamas.png',28,62,25,66,word='Gail'),obj('ella','ella-modern.png' if modern else 'ella.png',73,62,25,65,word='Ella',flip=not modern)]
def prop(id,file,word=None,x=50,y=78,w=24,h=27,z=5):return obj(id,file+'.png',x,y,w,h,z,word)
scenes=[]
for s,l in zip(o['scenes'],levels):
 n=s['number'];modern=18<=n<=23
 bg='palace';items=pair(modern);target='ella'
 if n in [1,2,24]:bg='bedroom';items=[obj('gail','gail-home.png',29,69,36,56),prop('watch','watch',x=64,y=67,w=17,h=22)];target='watch'
 if n in [3,4]:items.append(prop('watch','watch',x=51,y=72,w=18,h=22));target='ella' if n==3 else 'watch'
 if n==5:items.append(prop('watch','watch',x=48,y=67,w=17,h=22));target='watch'
 if n==6:bg='london';items.append(prop('ticket','ticket',word='UK',w=18,h=20));target='ticket'
 if n in [7,8,9]:bg='cinema';items.append(prop('ticket','ticket',word='movie ticket',w=20,h=23));target='ticket'
 if n in [10,11]:bg='restaurant';items=[obj('friends','cafe-pair.png',50,60,88,78,3,'Gail and Ella'),prop('meal','meal',word='French fries and coke',w=29,h=25,y=54)];target='meal'
 if n in [12,13]:bg='restaurant';items=[obj('friends','cafe-pair.png',50,60,88,78,3,'Gail and Ella'),prop('dessert','dessert',word='ice cream',w=30,h=25,y=54)];target='dessert'
 if n==14:bg='hotel'
 if n==15:bg='underground';items.append(prop('ticket','ticket',word='train ticket',w=18,h=20));target='ticket'
 if n in [16,17,18,19]:
  bg='store';items=pair(modern);items[0].update(x=25);items[1].update(x=64)
  if n in [16,17,18]:items.append(prop('clothes','clothes',word='clothes',x=47,y=70,w=27,h=49,z=2));target='clothes'
  else:target='ella'
 if n==20:bg='london';items.append(prop('watch','watch',x=50,y=71,w=18,h=22));target='watch'
 if n==21:bg='london';items.append(prop('watch','watch',x=48,y=67,w=17,h=22));target='watch'
 if n in [22,23]:items.append(prop('watch','watch',x=49,y=69,w=17,h=22));target='watch' if n==23 else 'ella'
 if n in [2,5,21,23]:items.append(obj('portal','portal.svg',51,42,37,72,2,'doorway'))
 scenes.append(dict(number=n,title=s['title'],scene=bg,background=f'images/story/{key}-v1/{bg}.png',objects=items,text={'A':[l['A']],'B':[l['B']],'C':[s['en']]},chinese={'A':[l['AZ']],'B':[l['BZ']],'C':[s['zh']]},mission=dict(type='tap',answer=target,prompt='Explore the '+next(i['word'] for i in items if i['id']==target)+'.',hint='點選星星提示，聽單字並觀察這一幕的動作。'),visual=s['visual']))
quizraw=[(2,1,'What opens the doorway?',['A movie ticket.','The golden watch.','A T-shirt.'],1),(4,2,'Why does Ella want a little holiday?',['She wants to see the world outside.','She lost her crown.','She wants to build a castle.'],0),(8,3,'Where do the friends go on Saturday?',['To a mountain.','To a lake.','To a movie theater.'],2),(12,4,'Which ice cream does Gail choose?',['Banana.','Lemon.','Chocolate.'],1),(18,5,'Where does Gail change out of her pajamas?',['At the department store.','At the movie theater.','In the castle before the trip.'],0),(24,6,'Where does Gail put the watch at the end?',['On a train.','In the restaurant.','Beside her bed.'],2)]
qs=[];(P/'quiz').mkdir(exist_ok=True)
for j,(scene,board,q,choices,a) in enumerate(quizraw,1):
 ext='jpeg' if board==5 else 'png';name=f'question-{j:02}.{ext}';shutil.copy2(D/f'images/board-{board:02}.{ext}',P/'quiz'/name)
 qs.append(dict(number=j,kind='choice',scene=scene,question=q,options=choices,answerIndex=a,answer=choices[a],image=f'images/story/{key}-v1/quiz/{name}'))
core=json.loads((D/'core-words.json').read_text());icons=['london','cinema','cinema','store','store','ella','ella','restaurant','dessert','meal','meal','dessert','dessert','dessert','underground','ella','watch','ella','clothes','clothes','clothes']
m=dict(number=49,id=key,title=o['title'],chineseTitle=o['titleZh'],coreWords=o['words'],wordBasis='使用者指定21詞，24幕ABC中英；分級為設計目標，非實測',scenes=scenes,quiz=qs,vocabulary=[dict(word=w['word'],chinese=w['chinese'],cue=w['chinese'],image=f'images/story/{key}-v1/{im}.png') for w,im in zip(core,icons)],readingTargets={'A':'跟讀','B':'BR–100L（設計目標）','C':'190L–530L（設計目標）'},status='正式閱讀器製作，部署待驗證')
(F/'ebook').mkdir(exist_ok=True);(F/'ebook/scene-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));(R/'production-scenes/princess-weekend.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));(D/'reader-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
(R/'src/story/interactive/princess-weekend-data.ts').write_text('export default '+json.dumps({key:m},ensure_ascii=False,separators=(',',':'))+';\n')
(R/'princess-weekend-storybook.html').write_text('<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>'+o['title']+' · 學習星球</title><link rel="stylesheet" href="modules/book-49/reader.css"></head><body data-story="princess-weekend" data-shelf-url="https://learnplanet.win/story-planet.html"><main id="little-star"></main><script defer src="modules/book-49/reader.js"></script></body></html>')
print('24 scenes, 21 words, 6 picture questions; modern outfit starts in 18.')
